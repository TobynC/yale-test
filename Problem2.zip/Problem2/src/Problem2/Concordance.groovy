package Problem2

class Sentence {
    ArrayList<String> _words

    Sentence(ArrayList<String> words) {
        _words = words
    }
}

class Word {
    String _value, _sentences
    int _frequency

    Word(String v, String s){
        _value = v
        _frequency = 1
        _sentences = s
    }
}

class Concordance {
    private String _input
    private ArrayList<Sentence> _sentences
    private ArrayList<Word> _words

    Concordance(String input){
        _input = input
        _sentences = new ArrayList<Sentence>()
        _words = new ArrayList<Word>()
    }

    private String AddWhiteSpace(int n) {
        def space = ''
        for(def i = 0; i < n; i++) space+=' '

        return space
    }

    String Generate(){
        def sb = new StringBuilder()

        _input.split('(?<!\\w\\.\\w.)(?<![A-Z][a-z]\\.)(?<=\\.|\\?)\\s').each {
            sentence ->
                _sentences.add(new Sentence(
                        sentence.split(' ').collect {
                            word -> word.toLowerCase().replaceAll('[ ,.:]', '')
                        }))
        }

        for(def i = 0; i < _sentences.size(); i++) {
            for(def j = 0; j < _sentences[i]._words.size(); j++) {
                def word = _sentences[i]._words[j]

                if(_words.any { it._value == word }) {
                    def index = _words.findIndexOf { it._value == word}

                    _words[index]._frequency = _words[index]._frequency + 1
                    _words[index]._sentences = _words[index]._sentences + ",${i + 1}"
                }
                else _words.add(new Word(word, (i+1).toString()))
            }
        }

        def label = 1
        for(def word in _words.sort { it._value }) {
            def whitespace = 30 - (word._value.length() + label.toString().length())

            sb.append("$label. ${word._value}${AddWhiteSpace(whitespace)}{${word._frequency}:${word._sentences}}\n")
            label++
        }

        return sb.toString()
    }
}